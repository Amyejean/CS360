package com.example.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button buttonLogin, buttonCreateAccount;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText()
                    .toString().trim();
            String password = editPassword.getText()
                    .toString();

            if (username.isEmpty() || password.length() < 8) {
                Toast.makeText(this,
                        "Enter a username and password of at least 8 characters",
                        Toast.LENGTH_LONG).show();
                return;
            }

            boolean created =
                    databaseHelper.createUser(username, password);

            if (created) {
                Toast.makeText(this,
                        "Account created! Please log in.",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "Unable to create account. Username may already exist.",
                        Toast.LENGTH_LONG).show();
            }
        });

        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText()
                    .toString().trim();
            String password = editPassword.getText()
                    .toString();

            if (databaseHelper.checkUser(username, password)) {
                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                int userId = databaseHelper.getUserId(username);

                if (userId != -1) {
                    Intent intent = new Intent(
                            MainActivity.this, SmsActivity.class);

                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                } else {
                    Toast.makeText(this,
                            "Unable to find user account",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this,
                        "Incorrect username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
