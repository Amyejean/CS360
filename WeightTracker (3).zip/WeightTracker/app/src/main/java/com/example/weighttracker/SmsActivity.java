package com.example.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Button buttonAllowSms =
                findViewById(R.id.buttonAllowSms);

        Button buttonDenySms =
                findViewById(R.id.buttonDenySms);

        buttonAllowSms.setOnClickListener(v ->
                checkSmsPermission());

        buttonDenySms.setOnClickListener(v -> {
            Toast.makeText(this,
                    "SMS notifications are disabled.",
                    Toast.LENGTH_SHORT).show();

            openDataScreen();
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this,
                    "SMS permission granted.",
                    Toast.LENGTH_SHORT).show();

            openDataScreen();

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] ==
                            PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this,
                        "SMS permission granted.",
                        Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this,
                        "SMS permission denied. App will continue.",
                        Toast.LENGTH_SHORT).show();
            }

            openDataScreen();
        }
    }

    private void openDataScreen() {
        int userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this,
                    "User account not found. Please log in again.",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Intent intent = new Intent(
                SmsActivity.this, DataActivity.class);

        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }

}

