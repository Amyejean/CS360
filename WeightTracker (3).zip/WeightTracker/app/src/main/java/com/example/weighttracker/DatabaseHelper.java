package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 2;
    private static final int ITERATIONS = 120000;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE NOT NULL," +
                "password_hash BLOB NOT NULL," +
                "salt BLOB NOT NULL)");

        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "weight REAL NOT NULL CHECK(weight > 0)," +
                "entry_date TEXT NOT NULL," +
                "goal REAL," +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL(
                    "ALTER TABLE weights ADD COLUMN goal REAL"
            );
        }
    }

    private byte[] hashPassword(String password, byte[] salt)
            throws Exception {
        char[] chars = password.toCharArray();
        KeySpec spec = new PBEKeySpec(
                chars, salt, ITERATIONS, 256);

        try {
            return SecretKeyFactory
                    .getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec)
                    .getEncoded();
        } finally {
            Arrays.fill(chars, '\0');
        }
    }

    // CREATE ACCOUNT
    public boolean createUser(String username, String password) {
        username = username.trim();

        if (username.isEmpty() || password.length() < 8) {
            return false;
        }

        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            ContentValues values = new ContentValues();
            values.put("username", username);
            values.put("password_hash",
                    hashPassword(password, salt));
            values.put("salt", salt);

            long result = getWritableDatabase().insert(
                    "users", null, values);

            return result != -1;

        } catch (Exception e) {
            return false;
        }
    }

    // CHECK LOGIN
    public boolean checkUser(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"password_hash", "salt"},
                "username=?",
                new String[]{username.trim()},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] storedHash = cursor.getBlob(0);
            byte[] salt = cursor.getBlob(1);
            byte[] attemptedHash = hashPassword(password, salt);

            return MessageDigest.isEqual(
                    storedHash, attemptedHash);

        } catch (Exception e) {
            return false;
        }
    }

    // GET USER ID
    public int getUserId(String username) {
        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"id"},
                "username=?",
                new String[]{username.trim()},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        }

        return -1;
    }

    // ADD WEIGHT
    public long addWeight(int userId, double weight,
                           String date, double goal) {

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("weight", weight);
        values.put("entry_date", date);
        values.put("goal", goal);

        return getWritableDatabase().insert(
                "weights", null, values);
    }

    // READ WEIGHTS
    public Cursor getWeights(int userId) {
        return getReadableDatabase().query(
                "weights",
                new String[]{"id", "weight", "entry_date", "goal"},
                "user_id=?",
                new String[]{String.valueOf(userId)},
                null, null,
                "entry_date DESC, id DESC"
        );
    }

    // UPDATE WEIGHT
    public boolean updateWeight(int id, int userId,
                                double weight, String date,
                                double goal) {

        ContentValues values = new ContentValues();
        values.put("weight", weight);
        values.put("entry_date", date);
        values.put("goal", goal);

        int rows = getWritableDatabase().update(
                "weights",
                values,
                "id=? AND user_id=?",
                new String[]{
                        String.valueOf(id),
                        String.valueOf(userId)
                });

        return rows > 0;
    }

    // DELETE WEIGHT
    public boolean deleteWeight(int id, int userId) {

        int rows = getWritableDatabase().delete(
                "weights",
                "id=? AND user_id=?",
                new String[]{
                        String.valueOf(id),
                        String.valueOf(userId)
                });

        return rows > 0;
    }
}