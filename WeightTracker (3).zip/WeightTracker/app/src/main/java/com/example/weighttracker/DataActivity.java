package com.example.weighttracker;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DataActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout tableWeight;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        databaseHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this,
                    "Please log in again",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        tableWeight = findViewById(R.id.tableWeight);
        Button buttonAdd = findViewById(R.id.buttonAdd);

        buttonAdd.setOnClickListener(v -> showAddDialog());

        loadWeights();
    }

    private void showAddDialog() {

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        EditText inputWeight = new EditText(this);
        inputWeight.setHint("Weight in pounds");
        inputWeight.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText inputGoal = new EditText(this);
        inputGoal.setHint("Goal weight in pounds");
        inputGoal.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL);

        EditText inputDate = new EditText(this);
        inputDate.setHint("YYYY-MM-DD");

        String today = new SimpleDateFormat(
                "yyyy-MM-dd", Locale.US).format(new Date());

        inputDate.setText(today);

        layout.addView(inputWeight);
        layout.addView(inputGoal);
        layout.addView(inputDate);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Weight")
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(v -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(view -> {

                        String weightText = inputWeight.getText()
                                .toString().trim();
                        String date = inputDate.getText()
                                .toString().trim();

                        double weight;

                        try {
                            weight = Double.parseDouble(weightText);
                        } catch (NumberFormatException e) {
                            inputWeight.setError("Enter a valid weight");
                            return;
                        }

                        if (!Double.isFinite(weight) || weight <= 0) {
                            inputWeight.setError("Weight must be greater than 0");
                            return;
                        }

                        if (!validDate(date)) {
                            inputDate.setError("Use YYYY-MM-DD");
                            return;
                        }
                        double goal;

                        try {
                            goal = Double.parseDouble(
                                    inputGoal.getText().toString().trim());
                        } catch (NumberFormatException e) {
                            inputGoal.setError("Enter a valid goal weight");
                            return;
                        }

                        if (!Double.isFinite(goal) || goal <= 0) {
                            inputGoal.setError("Goal must be greater than 0");
                            return;
                        }
                        long result = databaseHelper.addWeight(
                                userId, weight, date, goal);

                        if (result != -1) {
                            Toast.makeText(this,
                                    "Weight saved successfully!",
                                    Toast.LENGTH_SHORT).show();

                            dialog.dismiss();
                            loadWeights();
                        } else {
                            Toast.makeText(this,
                                    "Unable to save weight",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        dialog.show();
    }

    private boolean validDate(String date) {
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return false;
        }

        SimpleDateFormat format =
                new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        format.setLenient(false);

        try {
            format.parse(date);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void loadWeights() {

        // Keep the existing table header.
        while (tableWeight.getChildCount() > 1) {
            tableWeight.removeViewAt(1);
        }

        try (Cursor cursor = databaseHelper.getWeights(userId)) {

            while (cursor.moveToNext()) {

                int id = cursor.getInt(0);
                double weight = cursor.getDouble(1);
                String date = cursor.getString(2);
                String goalText = cursor.isNull(3)
                        ? "-"
                        : String.valueOf(cursor.getDouble(3));
                double currentGoal = cursor.isNull(3)
                        ? 0
                        : cursor.getDouble(3);

                TableRow row = new TableRow(this);

                addCell(row, date);
                addCell(row, String.valueOf(weight));
                addCell(row, goalText);

                LinearLayout actionLayout = new LinearLayout(this);
                actionLayout.setOrientation(LinearLayout.HORIZONTAL);

                Button editButton = new Button(this);
                editButton.setText("Edit");
                editButton.setTextSize(12);
                editButton.setContentDescription("Edit weight entry");

                editButton.setOnClickListener(v ->
                        showEditDialog(id, weight, date, currentGoal));

                Button deleteButton = new Button(this);
                deleteButton.setText("X");
                deleteButton.setTextSize(12);
                deleteButton.setContentDescription("Delete weight entry");

                deleteButton.setOnClickListener(v ->
                        confirmDelete(id));

                actionLayout.addView(editButton);
                actionLayout.addView(deleteButton);

                row.addView(actionLayout);

                tableWeight.addView(row);
            }
        }
    }

    private void addCell(TableRow row, String text) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setPadding(8, 12, 8, 12);
        row.addView(cell);
    }

    private void confirmDelete(int id) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight")
                .setMessage("Delete this weight entry?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (databaseHelper.deleteWeight(id, userId)) {
                        loadWeights();
                    } else {
                        Toast.makeText(this,
                                "Unable to delete entry",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    private void showEditDialog(int id, double currentWeight,
                                String currentDate, double currentGoal) {

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        EditText inputWeight = new EditText(this);
        inputWeight.setHint("Weight in pounds");
        inputWeight.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL);
        inputWeight.setText(String.valueOf(currentWeight));

        EditText inputGoal = new EditText(this);
        inputGoal.setHint("Goal weight in pounds");
        inputGoal.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL);

        if (currentGoal > 0) {
            inputGoal.setText(String.valueOf(currentGoal));
        }

        EditText inputDate = new EditText(this);
        inputDate.setHint("YYYY-MM-DD");
        inputDate.setText(currentDate);

        layout.addView(inputWeight);
        layout.addView(inputGoal);
        layout.addView(inputDate);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Weight")
                .setView(layout)
                .setPositiveButton("Save Changes", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(v -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(view -> {

                        double newWeight;

                        try {
                            newWeight = Double.parseDouble(
                                    inputWeight.getText().toString().trim());
                        } catch (NumberFormatException e) {
                            inputWeight.setError("Enter a valid weight");
                            return;
                        }

                        if (!Double.isFinite(newWeight) || newWeight <= 0) {
                            inputWeight.setError("Enter a positive weight");
                            return;
                        }

                        String newDate = inputDate.getText()
                                .toString().trim();

                        if (!validDate(newDate)) {
                            inputDate.setError("Use a valid YYYY-MM-DD date");
                            return;
                        }
                        double newGoal;

                        try {
                            newGoal = Double.parseDouble(
                                    inputGoal.getText().toString().trim());
                        } catch (NumberFormatException e) {
                            inputGoal.setError("Enter a valid goal weight");
                            return;
                        }

                        if (!Double.isFinite(newGoal) || newGoal <= 0) {
                            inputGoal.setError("Goal must be greater than 0");
                            return;
                        }

                        boolean updated = databaseHelper.updateWeight(
                                id, userId, newWeight, newDate, newGoal);

                        if (updated) {
                            Toast.makeText(this,
                                    "Weight updated successfully!",
                                    Toast.LENGTH_SHORT).show();

                            dialog.dismiss();
                            loadWeights();
                        } else {
                            Toast.makeText(this,
                                    "Unable to update weight",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        dialog.show();
    }

}
